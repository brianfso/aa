import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { EquiposController } from './modules/equipos/equipos.controller';
import { StadiumsController } from './modules/stadiums/stadiums.controller';
import { StadiumsModule } from './modules/stadiums/stadiums.module';
import { EquiposModule } from './modules/equipos/equipos.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EquiposEntity } from './entities/equipos.entity';
import { ConfigEntity } from './entities/configSistema.entity';
import { StadiumsEntity } from './entities/stadiums.entity';
import { UsuarioEntity } from './entities/usuario.entity';
import { LoginModule } from './modules/login/login.module';
import { AuthModule } from './modules/auth/auth.module';
import { ConfigSistemaModule } from './modules/config-sistema/config-sistema.module';
import { UsuarioModule } from './modules/usuario/usuario.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type:'postgres',
      host:'localhost',
      port:5432,
      username:'cliente',//'postgres',
      password:'cliente',
      database:'mundialdb',
      entities:[
        EquiposEntity, 
        UsuarioEntity,
        StadiumsEntity,
        ConfigEntity,        
      ],
      synchronize:true
    })
    ,
    LoginModule,
    AuthModule, UsuarioModule, ConfigSistemaModule
    ,StadiumsModule, EquiposModule],
  controllers: [AppController, EquiposController, StadiumsController],
  providers: [AppService],
})
export class AppModule {}
