import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UsuarioEntity } from 'src/entities/usuario.entity';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
@Injectable()
export class LoginService {
    constructor(
        @InjectRepository(UsuarioEntity)
        private usuarioRepository:Repository<UsuarioEntity>,
        //private jwtService:JwtService
    ){}

    /*getUser(id:number){
        return this.usuarioRepository.findOneBy({Id:id});
    }
    
    async findOne(login:string,password:string):Promise<any>{
        return  this.usuarioRepository.findOne({where:{
            Login:login,
            Password:password
        }});
    }
    getToken(usuario:any){
        const payload={
            usuario:usuario
        };
        return {
            access_token:this.jwtService.sign(payload)
        }

    }*/

}
