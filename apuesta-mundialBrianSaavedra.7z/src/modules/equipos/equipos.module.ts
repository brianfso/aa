import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EquiposEntity } from 'src/entities/equipos.entity';
import { ConfigSistemaModule } from '../config-sistema/config-sistema.module';
import { StadiumsController } from '../stadiums/stadiums.controller';

import { EquiposService } from './equipos.service';

@Module({
  imports:[
    TypeOrmModule.forFeature([EquiposEntity]),
    ConfigSistemaModule
  ],
  controllers: [StadiumsController],
  providers: [EquiposService]
})
export class EquiposModule {}
