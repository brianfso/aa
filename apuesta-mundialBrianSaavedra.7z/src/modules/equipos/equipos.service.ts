import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { EquiposEntity } from 'src/entities/equipos.entity';
import { Equipo } from 'src/modelos/equipos';
import { Repository } from 'typeorm';


@Injectable()
export class EquiposService {
    constructor(
        @InjectRepository(EquiposEntity)
        private equipoRepository:Repository<EquiposEntity>,
    ){}

    GetEquiposLista():Promise<Equipo[]>{
        return this.equipoRepository.find(
            {
                where:{Estado:1},
                //skip:3,// inicio
                //take:3// cantidad
            }
        );
    }
    GetEquiposListaPaginar(skip:number,take:number):Promise<Equipo[]>{
        return this.equipoRepository.find(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
    }
    async GetEquiposListaPaginarPorPagina(skip:number,take:number):Promise<any>{
        const [lista,count]= await this.equipoRepository.findAndCount(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
        //console.log(lista,count);
        return {lista,count,skip,take};
    }
    GetEquipos():Promise<any>{
        return this.equipoRepository.find(
            {where:{Estado:1}}
        );
    }
}
