import { Controller } from '@nestjs/common';

@Controller('equipos')
export class EquiposController {}
