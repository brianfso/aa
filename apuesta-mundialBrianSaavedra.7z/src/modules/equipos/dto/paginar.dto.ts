import { ApiProperty } from "@nestjs/swagger";
import { Type } from "class-transformer";
import { IsInt, IsOptional, IsString } from "class-validator";

export class PaginarDTO{
    @ApiProperty()
    @IsInt()
    @IsOptional()
    @Type(()=>Number)
    skip:number;

    @ApiProperty()
    @IsInt()
    @IsOptional()
    @Type(()=>Number)
    take:number;
}