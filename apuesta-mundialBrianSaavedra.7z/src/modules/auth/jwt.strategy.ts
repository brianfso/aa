import { Injectable } from "@nestjs/common";
import { ExtractJwt,  } from "passport-jwt";
import {  Strategy } from "passport-jwt";
import { PassportStrategy } from '@nestjs/passport';
import { jwtConstants } from "src/constants/jwt.datos";

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {    
    constructor() {
        super({
          jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
          ignoreExpiration: false,
          secretOrKey: jwtConstants.secret,
        });
      }
    
      async validate(payload: any) {
        return { Id: payload.Id, Nombres: payload.Nombres };
      }
}
