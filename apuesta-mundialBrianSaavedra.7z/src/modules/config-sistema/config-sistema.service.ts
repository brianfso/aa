import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ConfigEntity } from 'src/entities/configSistema.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ConfigSistemaService {

    constructor( @InjectRepository(ConfigEntity)
    private configRepository:Repository<ConfigEntity>,){
    }

    async GetConfig(config:string){
        const configuracion = await this.configRepository
            .findOne({where:{ Nombre:config }});
        return configuracion?configuracion.Valor:'';
    }
    async SetConfig(config:string,valor:string){
        let configEntity=new   ConfigEntity();
        configEntity.Nombre=config;
        configEntity.Valor=valor;
        const dato = await this.configRepository.save(configEntity);
        return dato;
    }
}
