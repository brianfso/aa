import { Module } from '@nestjs/common';


import { UsuarioService } from './usuario.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsuarioEntity } from 'src/entities/usuario.entity';
import { JwtModule } from '@nestjs/jwt';
import { jwtConstants } from 'src/constants/jwt.datos';
import { JwtStrategy } from '../auth/jwt.strategy';

@Module({
  imports:[
    TypeOrmModule.forFeature([UsuarioEntity]),
    
    JwtModule.register({
      secret:jwtConstants.secret,
      signOptions:{expiresIn:'60m'},
    })
  ],
  providers: [
    UsuarioService,JwtStrategy],
  exports:[UsuarioService]
})
export class UsuarioModule {}
