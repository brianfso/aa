import { Injectable } from '@nestjs/common';
import { StadiumsEntity } from 'src/entities/stadiums.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Stadium } from 'src/modelos/stadiums';


@Injectable()
export class StadiumsService {
    constructor(
        @InjectRepository(StadiumsEntity)
        private stadiumRepository:Repository<StadiumsEntity>,
    ){}

    GetStadiumsLista():Promise<Stadium[]>{
        return this.stadiumRepository.find(
            {
                where:{Estado:1},
                //skip:3,// inicio
                //take:3// cantidad
            }
        );
    }
    GetStadiumsListaPaginar(skip:number,take:number):Promise<Stadium[]>{
        return this.stadiumRepository.find(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
    }
    async GetStadiumsListaPaginarPorPagina(skip:number,take:number):Promise<any>{
        const [lista,count]= await this.stadiumRepository.findAndCount(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
        //console.log(lista,count);
        return {lista,count,skip,take};
    }
    GetStadiums():Promise<any>{
        return this.stadiumRepository.find(
            {where:{Estado:1}}
        );
    }
}
