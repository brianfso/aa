import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { ConfigSistemaService } from '../config-sistema/config-sistema.service';
import { StadiumsService } from './stadiums.service';


@Controller('stadiums')
export class StadiumsController {
    /**
 * lista-> get
 * insertr->post
 * editar->put
 * borrar->delete
 * 
 */
     constructor(
        private stadiumService:StadiumsService,
        private configService:ConfigSistemaService
    ){}

    @UseGuards(JwtAuthGuard)
    @Get()
    ListaStadiums(@Request() req){
        //console.log(req.user);
        return this.stadiumService.GetStadiumsLista()
        .then(stadiumsServer=>{
            return stadiumsServer;
        })
    }

    //:TODOS get www.dominio.com/candidatos?inicio=1&cantidad=5
    //:TODOS get www.dominio.com/candidatos/1/5
    //:TODOS post www.dominio.com/candidatos
    //          {inicio=1,cantidad=5}

    //@UseGuards(JwtAuthGuard)
    @Get('listaPagina')
    ListaStadiumsPaginar(
        //@Request() req, 
        @Query() params:{skip:number,take:number})
    {
        //console.log(req.user);
        //console.log("parametros url5",params)
        const {skip, take}=params;
        //console.log("parametros url5",skip,take)
        return this.stadiumService.GetStadiumsListaPaginar(skip,take)
       /* .then(candidatosServer=>{
            return candidatosServer;
        })*/
    }
    @Get('listaPaginaPorPagina')
    async ListaStadiumsPaginarPorPagina(
        @Request() req, 
        @Query() params:{skip:number,take:number})
    {
        this.Inicializar();
        console.log(req.user);
        
        const cantidad= Number(await this.configService.GetConfig('cantidadPagina'));

        let {skip, take}=params;
        skip=skip?skip:0;
        take=take?take:cantidad;
        //console.log("parametros url5",skip,take)
        return  this.stadiumService.GetStadiumsListaPaginarPorPagina(skip,take)
        .then(stadiumsServer=>{
            return stadiumsServer;
        })
    }

    private async  Inicializar(){
        const cantidad= await this.configService.GetConfig("cantidadPagina");
        if(cantidad==='')
            this.configService.SetConfig("cantidadPagina",'5');
    }
}
