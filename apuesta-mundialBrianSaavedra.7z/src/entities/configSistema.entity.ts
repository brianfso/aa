import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity("tb_config")
export class ConfigEntity{
    @PrimaryGeneratedColumn()
    Id:number;

    @Column()
    Nombre:string;

    @Column()
    Valor:string;
}