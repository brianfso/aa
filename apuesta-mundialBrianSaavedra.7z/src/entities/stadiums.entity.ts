import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity("tb_stadiums")
export class StadiumsEntity{
    @PrimaryGeneratedColumn()
    Id:number;

    @Column()
    NombreStadiums:string;

    @Column()
    Lugar:string;

   

}