import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity("tb_equipos")
export class EquiposEntity{
    @PrimaryGeneratedColumn()
    Id:number;

    @Column()
    NombreEquipos:string;

    @Column()
    Pais:string;

}