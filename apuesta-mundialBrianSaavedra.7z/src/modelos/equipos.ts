export class Equipo{

    Id:number=0;
    NombreEquipos:string='';
    Pais:string='';
    

}