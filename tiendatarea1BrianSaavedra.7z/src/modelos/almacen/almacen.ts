export class Almacen {
    Id:string='';
    Nombre:string='';
    Direccion:string='';
    Telefono:number;
    Lat:number=0;
    Lon:number=0;

    constructor(
        id:string,
        nombre:string,
        direccion:string,
        telefono:number,
        lat:number,
        lon:number
    )
        {
            this.Id = id;
            this.Nombre = nombre;
            this.Direccion = direccion;
            this.Telefono = telefono;
            this.Lat = lat;
        }
}
