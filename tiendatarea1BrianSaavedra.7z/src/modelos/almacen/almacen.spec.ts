import { Almacen } from './almacen';

describe('Almacen', () => {
  it('should be defined', () => {
    expect(new Almacen()).toBeDefined();
  });
});
