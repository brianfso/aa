import { Categoria } from './categoria';

describe('Categoria', () => {
  it('should be defined', () => {
    expect(new Categoria()).toBeDefined();
  });
});
