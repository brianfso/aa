export class Categoria {

    Id:string='';
    Nombre:string='';
    Descripcion:string='';
    Foto:string='';
    Estado:string='';

    constructor(
        id:string,
        nombre:string,
        descripcion:string,
        foto:string,
        estado:string
    )
        {
            this.Id = id;
            this.Nombre = nombre;
            this.Descripcion = descripcion;
            this.Foto = foto;
            this.Estado = estado;
        }
}
