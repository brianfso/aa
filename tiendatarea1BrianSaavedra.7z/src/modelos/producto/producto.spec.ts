import { Producto } from './producto';

describe('Producto', () => {
  it('should be defined', () => {
    expect(new Producto()).toBeDefined();
  });
});
