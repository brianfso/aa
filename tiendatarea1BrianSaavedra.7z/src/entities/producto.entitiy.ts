import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";
@Entity("tb_producto")
export class ProductoEntity{
    @PrimaryGeneratedColumn()
    Id:number;

    @Column()
    Nombre:string;

    @Column()
    Categoria:string;

    @Column({default:0, type:'double'})
    Precio:number;

    @Column({default:0, type:'double'})
    Cant:number;

    @Column("text")
    Descripcion:string;

    @Column()
    Foto:string;

    @Column({type:'int'})
    Estrella:number;
    
}