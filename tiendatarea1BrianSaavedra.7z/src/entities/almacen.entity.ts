import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";
@Entity("tb_almacen")
export class AlmacenEntity{
    @PrimaryGeneratedColumn()
    Id:number;

    @Column()
    Nombre:string;

    @Column()
    Direccion:string;

    @Column({type:'int'})
    Telefono:number;

    @Column({default:0, type:'double'})
    lat:number;

    @Column({default:0, type:'double'})
    lon:number;

}