import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";
@Entity("tb_categoria")
export class CategoriaEntity{
    @PrimaryGeneratedColumn()
    Id:number;

    @Column()
    Nombre:string;

    @Column("text")
    Descripcion:string;

    @Column()
    Foto:string;

    @Column()
    Estado:string;
    
}