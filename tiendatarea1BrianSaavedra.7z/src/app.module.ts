import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ProductoEntity } from './entities/producto.entitiy';
import { ProductoModule } from './modulos/producto/producto.module';
import { AlmacenController } from './modulos/almacen/almacen.controller';
import { CategoriaController } from './modulos/categoria/categoria.controller';
import { CategoriaModule } from './modulos/categoria/categoria.module';
import { AlmacenModule } from './modulos/almacen/almacen.module';

@Module({
  imports: [ProductoModule,
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: '10.77.62.43',//192.16.10.5//10.85.25.69
      port: 3306,
      username: 'cliente',
      password: 'cliente',
      database: 'tienda',
      entities: [ProductoEntity],
      synchronize: true,
      logging: true
    }),
    CategoriaModule,
    AlmacenModule,
  ],
  controllers: [AppController, AlmacenController, CategoriaController],
  providers: [AppService],
})
export class AppModule {}
