import { HttpException, HttpStatus } from "@nestjs/common";
import { Log } from "./log";

export class TemplateTrabajo{
    Ejecutar(servicio:any,datosProducto:any){
        try{
            return servicio.AgregarProducto(datosProducto).then((productoServer)=>{
                return productoServer;
            });
        }
        catch(error){
            Log.Log("sasas");
            return new HttpException('Hay problemas ajenos:'+error,HttpStatus.BAD_REQUEST);
        }
    }
}