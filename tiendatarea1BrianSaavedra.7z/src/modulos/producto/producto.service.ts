import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { rejects } from 'assert';
import { resolve } from 'path';
import { ProductoEntity } from 'src/entities/producto.entitiy';
import { Producto } from 'src/modelos/producto/producto';
import { Repository } from 'typeorm';

@Injectable()
export class ProductoService {
    //private listaProducto:Producto[]=[];
    constructor(
        @InjectRepository(ProductoEntity)
        private productoRepositori:Repository<ProductoEntity>
   
        ){}
        //this.listaProducto.push(new Producto("1asd41","oreo","comestible",10,"galleta","",100));
    
    ListarProducto(){
        return this.productoRepositori.find();
        /*return new Promise((resolve,reject)=>{
            ///....
            resolve(this.listaProducto);
        });*/
    }
    AgregarProducto(producto:Producto){
        let productoEntity= new ProductoEntity();
        productoEntity.Cant=producto.Cant;
        productoEntity.Categoria=producto.Categoria;
        productoEntity.Descripcion=producto.Descripcion;
        productoEntity.Estrella=producto.Estrellas;
        productoEntity.Foto=producto.Foto;
        productoEntity.Nombre=producto.Nombre;
        productoEntity.Precio=producto.Precio;
        return this.productoRepositori.save(productoEntity);
        /*return new Promise((resolve,reject)=>{
            producto.Id='1asd'+this.listaProducto.length+1;
            this.listaProducto.push(producto);
            resolve(producto);
        });*/
    }
    async EditarrProducto(id:string,producto:Producto){
        
        let productoEntity = await this.productoRepositori.findOneBy({Id:Number(id)});
        if(!productoEntity)
            return new Promise((resolve,reject)=>{
                resolve(null);
            });
        productoEntity.Cant = producto.Cant;
        productoEntity.Categoria= producto.Categoria;
        productoEntity.Descripcion = producto.Descripcion;
        productoEntity.Estrella= producto.Estrellas;
        productoEntity.Foto=producto.Foto;
        productoEntity.Nombre = producto.Nombre;
        productoEntity.Precio = producto.Precio;
        return this.productoRepositori.save(productoEntity);
       /* return new Promise((resolve,reject)=>{
            let producto_=this.listaProducto.find(item=>{return item.Id===id});
            producto_.Cant=producto.Cant;
            producto_.Categoria=producto.Categoria;
            producto_.Descripcion=producto.Descripcion;
            producto_.Estrellas=producto.Estrellas;
            producto_.Foto=producto.Foto;
            producto_.Nombre=producto.Nombre;
            producto_.Precio=producto.Precio;
            resolve(producto_);
        });
    }*/
    }
    GetProducto(id:string){
        return this.productoRepositori.findOneBy({Id:Number(id)});
       /* return new Promise((resolve,reject)=>{
            let producto = this.listaProducto.find(item=>{return item.Id===id});
            resolve(producto);
        })*/
    }
    BorrarProducto(id:string){
        return this.productoRepositori.delete({Id:Number(id)});
        /*return new Promise((resolve,rejects)=>{
            let producto = this.listaProducto.find(item=>{return item.Id===id});
            if(producto){
                let index=this.listaProducto.indexOf(producto);
                this.listaProducto.splice(index,1);
                resolve(producto);
            }
            else
            resolve(null);
        })*/
    }

    }

