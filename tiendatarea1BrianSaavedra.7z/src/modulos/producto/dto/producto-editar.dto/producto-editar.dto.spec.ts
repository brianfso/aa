import { ProductoEditarDto } from './producto-editar.dto';

describe('ProductoEditarDto', () => {
  it('should be defined', () => {
    expect(new ProductoEditarDto()).toBeDefined();
  });
});
