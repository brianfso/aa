export class ProductoEditarDto {}
