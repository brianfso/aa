import { ProductoCrearDto } from './producto-crear.dto';

describe('ProductoCrearDto', () => {
  it('should be defined', () => {
    expect(new ProductoCrearDto()).toBeDefined();
  });
});
