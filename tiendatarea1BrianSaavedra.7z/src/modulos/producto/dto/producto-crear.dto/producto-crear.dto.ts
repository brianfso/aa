import { IsAlpha, IsAlphanumeric, IsDecimal, IsString, Length, Max, Min } from "class-validator";

export class ProductoCrearDto {
    
    @IsString({message:'Solo se acepta numeros y digitos en el nombre'})
    @Length(4,60,{message:'Debe tener como minimo 4 letras y un maximo de 60'})
    Nombre:string='';

    @IsDecimal({message:'Debe ser un numero, y/o con decimales precio'})
    Precio:number=0;

    @IsDecimal({message:'Debe ser un numero, y/o con decimales cant'})
    Cant:number=0;

    @IsString({message:"Solo se acepta numeros y digitos "})
    @Length(4,60,{message:"Debe tener como minimo 4 letras y un maximo de 60"})
    Descripcion:string='';

    @IsAlpha("es-ES",{message:'Debe ser un numero, y/o con decimales'})
    Categoria:string='';

    
    Foto:string='';

    @Min(0,{message:'Solo se acepta 0 estrellas como minimo'})
    @Max(5,{message:'Solo se acepta hasta 5 estrellas como maximo'})
    Estrellas: number=0;
    
    Id:string='0';
}
