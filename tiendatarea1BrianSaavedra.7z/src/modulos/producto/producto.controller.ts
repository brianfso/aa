import { Body, Controller, Delete, Get, HttpException, HttpStatus, NotImplementedException, Param, Post, Put } from '@nestjs/common';
import { get } from 'http';
import { Producto } from 'src/modelos/producto/producto';
import { isUndefined } from 'util';
import { ProductoCrearDto } from './dto/producto-crear.dto/producto-crear.dto';
import { ProductoService } from './producto.service';

//npm install --save @nestjs/typeorm typeorm mongodb@3.6.0

@Controller('producto')
export class ProductoController {
    constructor(private productoService:ProductoService){}
    @Get()
    ListaProducto():any{
        try{
            return this.productoService.ListarProducto().then((servidor)=>{
                return {
                    estado:true,
                    productos:servidor
                }
            }); 
        }catch(error){
            return new HttpException('Hay problemas ajenos:'+error,HttpStatus.BAD_REQUEST);
        }   
    }

    @Post()
    AgregarProducto(@Body() datosProducto:ProductoCrearDto){
        try{
            return this.productoService.AgregarProducto(datosProducto).then((productoServer)=>{
                return productoServer;
            });
        }
        catch(error){
            return new HttpException('Hay problemas ajenos:'+error,HttpStatus.BAD_REQUEST);
        }
    }

    @Get(":id")
    GetProducto(@Param() parametros:{id}){
        try{
            return this.productoService.GetProducto(parametros.id).then((productoServer)=>{
                return productoServer;
            });
        }
        catch(error){
            return new HttpException('Hay problemas ajenos:'+error,HttpStatus.BAD_REQUEST);
        }
    }

    @Put(":id")
    EditarProducto(@Param()parametros:{id},@Body() productoDto:ProductoCrearDto){
        try{
            return this.productoService.EditarrProducto(parametros.id,productoDto)
            .then((productoServer)=>{
                return productoServer;
            });
        }
        catch(error){
            return new HttpException('Hay problemas ajenos:'+error,HttpStatus.BAD_REQUEST);
        }
    }

    @Delete(":id")
    BorrarProducto(@Param() parametros:{id:number}){
        console.log("datos-->",parametros);
        try{
            return this.productoService.BorrarProducto(parametros.id+'')
            .then((productoServer)=>{
                return (productoServer)?
                    productoServer:{message:'No hay dato que borrar'};
            });
        }
        catch(error){
            return new HttpException('Hay problemas ajenos:'+error,HttpStatus.BAD_REQUEST);
        }
    }
}
