import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { AlmacenEntity } from 'src/entities/almacen.entity';
import { Almacen } from 'src/modelos/almacen/almacen';
import { Repository } from 'typeorm';

@Injectable()
export class AlmacenService {
    constructor(
        @InjectRepository(AlmacenEntity)
        private almacenRepositori:Repository<AlmacenEntity>
    ){}

    ListarAlmacen(){
        return this.almacenRepositori.find();
    }

    AgregarAlmacen(almacen:Almacen){
        let almacenEntity = new AlmacenEntity();
        almacenEntity.Nombre = almacen.Nombre;
        almacenEntity.Direccion = almacen.Direccion;
        almacenEntity.Telefono = almacen.Telefono;
        almacenEntity.Lat = almacen.Lat;
        almacenEntity.Lon = almacen.Lon;

        return this.almacenRepositori.save(almacenEntity);
    }

    async EditarAlmacen(id:string, almacen:Almacen){
        let almacenEntity = await this. almacenRepositori.findOneBy({Id:Number(id)})
        if(!almacenEntity)
        return new Promise ((resolve,reject)=>{
            resolve(null);
        });
        almacenEntity.Nombre = almacen.Nombre;
        almacenEntity.Direccion = almacen.Direccion;
        almacenEntity.Telefono = almacen.Telefono;
        almacenEntity.Lat = almacen.Lat;
        almacenEntity.Lon = almacen.Lon;
        
        return this.almacenRepositori.save(almacenEntity);
    }

    GetAlmacen(id:string){
        return this.almacenRepositori.findOneBy({Id:Number(id)})
    }

    BorrarAlmacen(id:string){
        return this.almacenRepositori.delete({Id:Number(id)})
    }
}
