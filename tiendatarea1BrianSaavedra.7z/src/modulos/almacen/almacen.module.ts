import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AlmacenEntity } from 'src/entities/almacen.entity';
import { AlmacenController } from './almacen.controller';
import { AlmacenService } from './almacen.service';

@Module({
  imports: [TypeOrmModule.forFeature([AlmacenEntity])],
  controllers: [AlmacenController],
  providers: [AlmacenService]
})
export class AlmacenModule {}
