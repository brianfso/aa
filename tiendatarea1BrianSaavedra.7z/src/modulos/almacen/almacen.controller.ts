import { Body, Controller, Delete, Get, HttpException, HttpStatus, Param, Post, Put } from '@nestjs/common';
import { AlmacenCrearDto } from '../almacen/almacen-crear.dto/almacen-crear.dto';
import { AlmacenService } from './almacen.service';

@Controller('almacen')
export class AlmacenController {
    constructor(private almacenService:AlmacenService){}
    
    @Get()
    ListaAlmacen():any
    {
        try{
            return this.almacenService.ListarAlmacen().then((servidor)=>{
                return {
                    estado:true,
                    productos:servidor
                }
            });
        }catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST);
        }
    }

    @Post()
    AgregarAlmacen(@Body() datosAlmacen:AlmacenCrearDto)
    {
        try{
            return this.almacenService.AgregarAlmacen(datosAlmacen)
            .then((almacenServer)=>{
                return almacenServer;
            });
        }
        catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
        }
    }

    @Get(":id")
    GetAlmacen(@Param() parametros:{id})
    {
        try{
            return this.almacenService.GetAlmacen(parametros.id).then((almacenServer)=>{
               return almacenServer; 
            });
        }
        catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
        }
    }

    @Put("id")
    EditarAlmacen(@Param()parametros:{id},@Body() almacenDto:AlmacenCrearDto){
        try{
            return this.almacenService.EditarAlmacen(parametros.id,almacenDto)
            .then((almacenServer)=>{
                return almacenServer;
            });
        }
        catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
        }

    }

    @Delete(":id")
    BorrarAlmacen(@Param()parametros:{id:number})
    {
      try{
        return this.almacenService.BorrarAlmacen(parametros.id+'' )
        .then((almacenServer)=>{
            return(almacenServer)?
            almacenServer:{message:'No hay dato que borrar'};
        });
    }  
    catch(error){
        return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
    }
    }

}



