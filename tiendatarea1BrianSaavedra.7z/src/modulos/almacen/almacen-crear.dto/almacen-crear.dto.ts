import {IsNumber, IsString, Length} from "class-validator";

export class AlmacenCrearDto {
    
    Id:string='0';

    @IsString({message:'Solo se acepta numeros y digitos en el nombre'})
    @Length(4,60,{message:'Debe tener como minimo 4 letras y un maximo de 60'})
    Nombre:string='';

    @IsString({message:"Solo se acepta numeros y digitos "})
    @Length(4,60,{message:"Debe tener como minimo 4 letras y un maximo de 60"})
    Direccion:string='';

    @IsNumber()
    @Length(4,60,{message:'Debe tener como minimo 4 letras y un maximo de 60'})
    Telefono:string='';

    @IsNumber()
    Lon:number=0;

    @IsNumber()
    Lat:number=0;
}