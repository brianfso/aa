import { AlmacenCrearDto } from './almacen-crear.dto';

describe('AlmacenCrearDto', () => {
  it('should be defined', () => {
    expect(new AlmacenCrearDto()).toBeDefined();
  });
});
