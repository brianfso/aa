import { Body, Controller, Delete, Get, HttpException, HttpStatus, Param, Post, Put } from '@nestjs/common';
import { CategoriaCrearDto } from './categoria-crear.dto/categoria-crear.dto';
import { CategoriaService } from './categoria.service';

@Controller('categoria')
export class CategoriaController {
    constructor(private categoriaService:CategoriaService){}
    
    @Get()
    ListaCategoria():any
    {
        try{
            return this.categoriaService.ListarCategoria().then((servidor)=>{
                return {
                    estado:true,
                    productos:servidor
                }
            });
        }catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST);
        }
    }

    @Post()
    AgregarCategoria(@Body() datosCategoria:CategoriaCrearDto)
    {
        try{
            return this.categoriaService.AgregarCategoria(datosCategoria)
            .then((productoServer)=>{
                return productoServer;
            });
        }
        catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
        }
    }

    @Get(":id")
    GetCategoria(@Param() parametros:{id})
    {
        try{
            return this.categoriaService.GetCategoria(parametros.id).then((categoriaServer)=>{
               return categoriaServer; 
            });
        }
        catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
        }
    }

    @Put("id")
    EditarProducto(@Param()parametros:{id},@Body() categoriaDto:CategoriaCrearDto){
        try{
            return this.categoriaService.EditarCategoria(parametros.id,categoriaDto)
            .then((categoriaServer)=>{
                return categoriaServer;
            });
        }
        catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
        }

    }

    @Delete(":id")
    BorrarProducto(@Param()parametros:{id:number})
    {
      try{
        return this.categoriaService.BorrarCategoria(parametros.id+'' )
        .then((categoriaServer)=>{
            return(categoriaServer)?
            categoriaServer:{message:'No hay dato que borrar'};
        });
    }  
    catch(error){
        return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
    }
    }


}
