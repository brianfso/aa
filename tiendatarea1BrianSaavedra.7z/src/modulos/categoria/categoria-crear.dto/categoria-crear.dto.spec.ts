import { CategoriaCrearDto } from './categoria-crear.dto';

describe('CategoriaCrearDto', () => {
  it('should be defined', () => {
    expect(new CategoriaCrearDto()).toBeDefined();
  });
});
