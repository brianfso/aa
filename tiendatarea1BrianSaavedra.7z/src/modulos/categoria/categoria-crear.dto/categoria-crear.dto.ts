import {IsString, Length} from "class-validator";

export class CategoriaCrearDto {
    
    Id:string='0';

    @IsString({message:'Solo se acepta numeros y digitos en el nombre'})
    @Length(4,60,{message:'Debe tener como minimo 4 letras y un maximo de 60'})
    Nombre:string='';

    @IsString({message:"Solo se acepta numeros y digitos "})
    @Length(4,60,{message:"Debe tener como minimo 4 letras y un maximo de 60"})
    Descripcion:string='';

    Foto:string='';

    @IsString()
    Estado:string='';
}