import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { CategoriaEntity } from 'src/entities/categoria.entity';
import { Categoria } from 'src/modelos/categoria/categoria';
import { Repository } from 'typeorm';

@Injectable()
export class CategoriaService {
    constructor(
        @InjectRepository(CategoriaEntity)
        private categoriaRepositori:Repository<CategoriaEntity>
    ){}

    ListarCategoria(){
        return this.categoriaRepositori.find();
    }

    AgregarCategoria(categoria:Categoria){
        let categoriaEntity = new CategoriaEntity();
        categoriaEntity.Nombre = categoria.Nombre;
        categoriaEntity.Descripcion = categoria.Descripcion;
        categoriaEntity.Foto = categoria.Foto;
        categoriaEntity.Estado = categoria.Estado;

        return this.categoriaRepositori.save(categoriaEntity);
    }

    async EditarCategoria(id:string, categoria:Categoria){
        let categoriaEntity = await this. categoriaRepositori.findOneBy({Id:Number(id)})
        if(!categoriaEntity)
        return new Promise ((resolve,reject)=>{
            resolve(null);
        });
        categoriaEntity.Nombre = categoria.Nombre;
        categoriaEntity.Descripcion = categoria.Descripcion;
        categoriaEntity.Foto = categoria.Foto;
        categoriaEntity.Estado = categoria.Estado;
        
        return this.categoriaRepositori.save(categoriaEntity);
    }

    GetCategoria(id:string){
        return this.categoriaRepositori.findOneBy({Id:Number(id)})
    }

    BorrarCategoria(id:string){
        return this.categoriaRepositori.delete({Id:Number(id)})
    }
}
