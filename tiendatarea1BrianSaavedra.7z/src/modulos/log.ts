export class Log{
    public static Log(msg:string){
        
    }

}