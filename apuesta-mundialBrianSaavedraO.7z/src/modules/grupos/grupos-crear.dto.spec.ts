import { GruposCrearDto } from './grupos-crear.dto';

describe('GruposCrearDto', () => {
  it('should be defined', () => {
    expect(new GruposCrearDto()).toBeDefined();
  });
});
