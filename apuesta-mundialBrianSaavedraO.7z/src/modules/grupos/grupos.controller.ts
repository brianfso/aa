import { Body, Controller, Delete, Get, HttpException, HttpStatus, Param, Post, Put, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { ConfigSistemaService } from '../config-sistema/config-sistema.service';
import { GruposService } from './grupos.service';

@Controller('grupos')
export class GruposController {
    /**
 * lista-> get
 * insertr->post
 * editar->put
 * borrar->delete
 * 
 */
     constructor(
        private grupoService:GruposService,
        private configService:ConfigSistemaService
       
        ){} 

        @UseGuards(JwtAuthGuard)
    @Get()
    Listagrupos(@Request() req){
        //console.log(req.user);
        return this.grupoService.GetGruposLista()
        .then(grupossServer=>{
            return gruposServer;
        })
    }
    
        @Post()
        AgregarGrupos(@Body() datosGrupo:GruposCrearDto)
        {
            try{
                return this.grupoService.AgregarGrupos(datosGrupo)
                .then((grupoServer)=>{
                    return grupoServer;
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
        }
    
        @Get(":id")
        GetGrupos(@Param() parametros:{id})
        {
            try{
                return this.grupoService.GetGrupos(parametros.id).then((gruposServer)=>{
                   return gruposServer; 
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
        }
    
        @Put("id")
        EditarGrupos(@Param()parametros:{id},@Body() stadiumsDto:GruposCrearDto){
            try{
                return this.grupoService.EditarGrupos(parametros.id,gruposDto)
                .then((gruposServer)=>{
                    return gruposServer;
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
    
        }
    
        @Delete(":id")
        BorrarGrupos(@Param()parametros:{id:number})
        {
          try{
            return this.grupoService.BorrarGrupos(parametros.id+'' )
            .then((grupoServer)=>{
                return(grupoServer)?
                grupoServer:{message:'No hay dato que borrar'};
            });
        }  
        catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
        }
        }

    

    @UseGuards(JwtAuthGuard)
    @Get('listaPagina')
    ListaGruposPaginar(
        @Query() params:{skip:number,take:number})
    {
        
        const {skip, take}=params;
        return this.grupoService.GetGruposListaPaginar(skip,take)
       
    }
    @Get('listaPaginaPorPagina')
    async ListaGruposPaginarPorPagina(
       
        @Query() params:{skip:number,take:number})
    {
        this.Inicializar();
        
        
        const cantidad= Number(await this.configService.GetConfig('cantidadPagina'));

        let {skip, take}=params;
        skip=skip?skip:0;
        take=take?take:cantidad;
        //console.log("parametros url5",skip,take)
        return  this.grupoService.GetGruposListaPaginarPorPagina(skip,take)
        .then(gruposServer=>{
            return gruposServer;
        })
    }

    private async  Inicializar(){
        const cantidad= await this.configService.GetConfig("cantidadPagina");
        if(cantidad==='')
            this.configService.SetConfig("cantidadPagina",'5');
    }
}
