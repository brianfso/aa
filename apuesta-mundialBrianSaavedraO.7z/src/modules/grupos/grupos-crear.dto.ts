import {IsString, Length} from "class-validator";


export class GruposCrearDto {
    
    Id:string='0';

    @IsString()
    @Length(4,60{message:"Debe tener como minimo 4 letras y un maximo de 60"})
    NombreGrupos:string='';
}
