import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';

@Injectable()
export class GruposService {
    constructor(
        @InjectRepository(GruposEntity)
        private grupoRepositori:Repository<GruposEntity>,
    ){}
    
    ListarGrupos(){
        return this.grupoRepositori.find();
    }
    GetGruposLista():Promise<Grupo[]>{
        return this.grupoRepositori.find(
            {
                where:{Estado:1},
                //skip:3,// inicio
                //take:3// cantidad
            }
        );
    }

    AgregarGrupos(grupos:Grupos){
        let gruposEntity = new GruposEntity();
        gruposEntity.NombreGrupos = grupos.NombreGrupos;
      
        

        return this.grupoRepositori.save(gruposEntity);
    }

    async EditarGrupos(id:string, Grupos:Grupo){
        let gruposEntity = await this.grupoRepositori.findOneBy({Id:Number(id)})
        if(!gruposEntity)
        return new Promise ((resolve,reject)=>{
            resolve(null);
        });
        gruposEntity.NombreGrupos = grupos.NombreGrupos;
        return this.grupoRepositori.save(gruposEntity);
    }

    BorrarGrupos(id:string){
        return this.grupoRepositori.delete({Id:Number(id)})
    }


    GetGruposListaPaginar(skip:number,take:number):Promise<Grupos[]>{
        return this.grupoRepositori.find(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
    }
    async GetGruposListaPaginarPorPagina(skip:number,take:number):Promise<any>{
        const [lista,count]= await this.grupoRepositori.findAndCount(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
        //console.log(lista,count);
        return {lista,count,skip,take};
    }
    GetGrupos():Promise<any>{
        return this.grupoRepositori.find(
            {where:{Estado:1}}
        );
    }
}
