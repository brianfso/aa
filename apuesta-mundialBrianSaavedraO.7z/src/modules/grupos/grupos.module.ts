import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GruposEntity } from 'src/entities/grupos.entity';
import { ConfigSistemaModule } from '../config-sistema/config-sistema.module';
import { GruposController } from './grupos.controller';
import { GruposService } from './grupos.service';

@Module({
  imports:[
    TypeOrmModule.forFeature([GruposEntity]),
    ConfigSistemaModule
  ],
  controllers: [GruposController],
  providers: [GruposService]
})
export class GruposModule {}
