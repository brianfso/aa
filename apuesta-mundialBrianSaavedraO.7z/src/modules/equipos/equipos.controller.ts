import { Body, Controller, Delete, Get, HttpException, HttpStatus, Param, Post, Put, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { ConfigSistemaService } from '../config-sistema/config-sistema.service';
import { EquiposService } from './equipos.service';

@Controller('equipos')
export class EquiposController {
    /**
 * lista-> get
 * insertr->post
 * editar->put
 * borrar->delete
 * 
 */
     constructor(
        private equipoService:EquiposService,
        private configService:ConfigSistemaService
       
        ){} 

        @UseGuards(JwtAuthGuard)
    @Get()
    ListaEquipos(@Request() req){
        //console.log(req.user);
        return this.equipoService.GetEquiposLista()
        .then(equiposServer=>{
            return equiposServer;
        })
    }
    
        @Post()
        AgregarEquipos(@Body() datosEquipos:EquiposCrearDto)
        {
            try{
                return this.equipoService.AgregarEquipos(datosEquipos)
                .then((equipoServer)=>{
                    return equipoServer;
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
        }
    
        @Get(":id")
        GetStadiums(@Param() parametros:{id})
        {
            try{
                return this.equipoService.GetEquipos(parametros.id).then((equiposServer)=>{
                   return equiposServer; 
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
        }
    
        @Put("id")
        EditarStadiums(@Param()parametros:{id},@Body() equiposDto:EquiposCrearDto){
            try{
                return this.equipoService.EditarEquipos(parametros.id,equiposDto)
                .then((stadiumsServer)=>{
                    return stadiumsServer;
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
    
        }
    
        @Delete(":id")
        BorrarEquipos(@Param()parametros:{id:number})
        {
          try{
            return this.equipoService.BorrarEquipos(parametros.id+'' )
            .then((equipoServer)=>{
                return(equipoServer)?
                equipoServer:{message:'No hay dato que borrar'};
            });
        }  
        catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
        }
        }

    

    @UseGuards(JwtAuthGuard)
    @Get('listaPagina')
    ListaStadiumsPaginar(
        @Query() params:{skip:number,take:number})
    {
        
        const {skip, take}=params;
        return this.equipoService.GetEquiposListaPaginar(skip,take)
       
    }
    @Get('listaPaginaPorPagina')
    async ListaEquiposPaginarPorPagina(
       
        @Query() params:{skip:number,take:number})
    {
        this.Inicializar();
        
        
        const cantidad= Number(await this.configService.GetConfig('cantidadPagina'));

        let {skip, take}=params;
        skip=skip?skip:0;
        take=take?take:cantidad;
        //console.log("parametros url5",skip,take)
        return  this.equipoService.GetEquiposListaPaginarPorPagina(skip,take)
        .then(equiposServer=>{
            return equiposServer;
        })
    }

    private async  Inicializar(){
        const cantidad= await this.configService.GetConfig("cantidadPagina");
        if(cantidad==='')
            this.configService.SetConfig("cantidadPagina",'5');
    }
}
