import { EquiposCrearDto } from './equipos-crear.dto';

describe('EquiposCrearDto', () => {
  it('should be defined', () => {
    expect(new EquiposCrearDto()).toBeDefined();
  });
});
