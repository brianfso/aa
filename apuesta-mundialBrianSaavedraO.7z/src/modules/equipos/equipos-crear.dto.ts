export class EquiposCrearDto {}
