import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { EquiposEntity } from 'src/entities/equipos.entity';
import { Equipo } from 'src/modelos/equipos';
import { Repository } from 'typeorm';


@Injectable()
export class EquiposService {
    constructor(
        @InjectRepository(EquiposEntity)
        private equipoRepositori:Repository<EquiposEntity>,
    ){}
    
    ListarEquipos(){
        return this.equipoRepositori.find();
    }

    AgregarEquipos(equipos:Equipo){
        let equiposEntity = new EquiposEntity();
        equiposEntity.NombreEquipos = equipos.NombreEquipos;
        equiposEntity.Pais = equipos.Pais;
        

        return this.equipoRepositori.save(equiposEntity);
    }

    async EditarEquipos(id:string, equipos:Equipo){
        let equiposEntity = await this. equipoRepositori.findOneBy({Id:Number(id)})
        if(!equiposEntity)
        return new Promise ((resolve,reject)=>{
            resolve(null);
        });
        equiposEntity.NombreEquipos = equipos.NombreEquipos;
        equiposEntity.Pais = equipos.Pais;
        return this.equipoRepositori.save(equiposEntity);
    }

    BorrarEquipos(id:string){
        return this.equipoRepositori.delete({Id:Number(id)})
    }
    GetEquiposLista(skip:number,take:number):Promise<Equipo[]>{
        return this.equipoRepositori.find(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
    }

    GetEquiposListaPaginar(skip:number,take:number):Promise<Equipo[]>{
        return this.equipoRepositori.find(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
    }
    async GetEquiposListaPaginarPorPagina(skip:number,take:number):Promise<any>{
        const [lista,count]= await this.equipoRepositori.findAndCount(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
        //console.log(lista,count);
        return {lista,count,skip,take};
    }
    GetEquipos():Promise<any>{
        return this.equipoRepositori.find(
            {where:{Estado:1}}
        );
    }
}
