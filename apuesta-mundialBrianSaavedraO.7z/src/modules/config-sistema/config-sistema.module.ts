import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigEntity } from 'src/entities/configSistema.entity';
import { ConfigSistemaService } from './config-sistema.service';

@Module({
  imports:[TypeOrmModule.forFeature([ConfigEntity])],
  providers: [ConfigSistemaService],
  exports:[ConfigSistemaService]
})
export class ConfigSistemaModule {}
