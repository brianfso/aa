import { HttpException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UsuarioEntity } from 'src/entities/usuario.entity';
import { Repository } from 'typeorm';
import { RegisterUserDto } from '../auth/dto/registerUser.dto';
import { hash, compare } from 'bcrypt';
import { UserDTO } from '../auth/dto/user.dto';
import { JwtService } from '@nestjs/jwt';
@Injectable()
export class UsuarioService {
    constructor(
        @InjectRepository(UsuarioEntity)
        private usuarioRepository:Repository<UsuarioEntity>,
        private jwtService:JwtService
        ){}

        async findOne(login:string,password:string):Promise<any>{
            return  this.usuarioRepository.findOne({where:{
                Login:login,
                Password:password
            }});
        }
        async register(user:RegisterUserDto){
            const {Password}=user;
            
            const plainToHash = await hash(Password,5);
            user.Password=plainToHash;
            user.Estado=1;
            console.log(user);
            return this.usuarioRepository.save(user);
        }
        async login(userDto: UserDTO) {
            
         const { Login, Password }=userDto;
         const findUser= await this.usuarioRepository.findOne({where:{Login:Login}});
         console.log("verifican",findUser);
         if(!findUser) throw new HttpException('User no found',404);
         const checkPassword = await compare(Password,findUser.Password);
         console.log("correcto",checkPassword);
         if(!checkPassword) throw  new HttpException('PASSWOR_INCORRECT',403);
         
         findUser.Password='';
         const payload={Id:findUser.Id,Nombres:findUser.Nombres};
         const token = await this.jwtService.sign(payload);
         const data = {
            user:findUser,
            token:token
         };
         return data;
        }
        
    }
