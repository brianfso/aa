import { ApuestaCrearDto } from './apuesta-crear.dto';

describe('ApuestaCrearDto', () => {
  it('should be defined', () => {
    expect(new ApuestaCrearDto()).toBeDefined();
  });
});
