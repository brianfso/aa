import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigSistemaModule } from '../config-sistema/config-sistema.module';
import { ApuestaController } from './apuesta.controller';
import { ApuestaService } from './apuesta.service';


@Module({

    imports:[
        TypeOrmModule.forFeature([ApuestaEntity]),
        ConfigSistemaModule
      ],
      controllers: [ApuestaController],
      providers: [
      ApuestaService]
        
      })
      export class ApuestaModule {}
