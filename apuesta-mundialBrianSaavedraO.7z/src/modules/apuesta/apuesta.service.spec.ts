import { Test, TestingModule } from '@nestjs/testing';
import { ApuestaService } from './apuesta.service';

describe('ApuestaService', () => {
  let service: ApuestaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ApuestaService],
    }).compile();

    service = module.get<ApuestaService>(ApuestaService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
