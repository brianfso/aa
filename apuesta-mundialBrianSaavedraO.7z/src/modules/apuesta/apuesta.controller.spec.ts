import { Test, TestingModule } from '@nestjs/testing';
import { ApuestaController } from './apuesta.controller';

describe('ApuestaController', () => {
  let controller: ApuestaController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ApuestaController],
    }).compile();

    controller = module.get<ApuestaController>(ApuestaController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
