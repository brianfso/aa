import { Body, Controller, Delete, Get, HttpException, HttpStatus, Param, Post, Put, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { ConfigSistemaService } from '../config-sistema/config-sistema.service';
import { ApuestaCrearDto } from './apuesta-crear.dto';

@Controller('apuesta')
export class ApuestaController {
    /**
 * lista-> get
 * insertr->post
 * editar->put
 * borrar->delete
 * 
 */
     constructor(
        private apuestaService: ApuestaService,
        private configService:ConfigSistemaService
       
        ){} 

        @UseGuards(JwtAuthGuard)
    @Get()
    ListaApuestas(){
        
        return this.apuestaService.GetApuetasLista()
        .then(apuetasServer=>{
            return apuetasServer;
        })
    }
    
        @Post()
        AgregarApuestas(@Body() datosApuesta:ApuestaCrearDto)
        {
            try{
                return this.apuestaService.AgregarApuestas(datosApuesta)
                .then((apuestaServer)=>{
                    return apuestaServer;
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
        }
    
        @Get(":id")
        GetStadiums(@Param() parametros:{id})
        {
            try{
                return this.apuestaService.GetApuestas(parametros.id).then((apuestasServer)=>{
                   return apuestasServer; 
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
        }
    
        @Put("id")
        EditarApuestas(@Param()parametros:{id},@Body() apuestasDto:ApuestaCrearDto){
            try{
                return this.apuestaService.EditarApuetas(parametros.id,apuestasDto)
                .then((apuestaServer)=>{
                    return apuestaServer;
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
    
        }
    
        @Delete(":id")
        BorrarApuestas(@Param()parametros:{id:number})
        {
          try{
            return this.apuestaService.BorrarApuestas(parametros.id+'' )
            .then((apuestaServer)=>{
                return(apuestaServer)?
                apuestaServer:{message:'No hay dato que borrar'};
            });
        }  
        catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
        }
        }

    

    @UseGuards(JwtAuthGuard)
    @Get('listaPagina')
    ListaApuesatsPaginar(
        @Query() params:{skip:number,take:number})
    {
        
        const {skip, take}=params;
        return this.apuestaService.GetApuestasListaPaginar(skip,take)
       
    }
    @Get('listaPaginaPorPagina')
    async ListaApuestasPaginarPorPagina(
       
        @Query() params:{skip:number,take:number})
    {
        this.Inicializar();
        
        
        const cantidad= Number(await this.configService.GetConfig('cantidadPagina'));

        let {skip, take}=params;
        skip=skip?skip:0;
        take=take?take:cantidad;
        //console.log("parametros url5",skip,take)
        return  this.apuestaService.GetStadiumsListaPaginarPorPagina(skip,take)
        .then(apuestaServer=>{
            return apuestaServer;
        })
    }

    private async  Inicializar(){
        const cantidad= await this.configService.GetConfig("cantidadPagina");
        if(cantidad==='')
            this.configService.SetConfig("cantidadPagina",'5');
    }
}
