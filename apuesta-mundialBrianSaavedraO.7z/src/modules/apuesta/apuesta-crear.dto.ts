import {IsNumber, Length} from "class-validator";
export class ApuestaCrearDto {

    Id:string='0';

    @IsNumber()
    @Length(1,60,{message:'Debe tener como minimo 4 letras y un maximo de 60'})
    Precio:number=0;
}
