import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class ApuestaService {
    constructor(
        @InjectRepository(ApuestasEntity)
        private apuestaRepositori:Repository<ApuestasEntity>,
    ){}
    
    ListarApuesta(){
        return this.apuestaRepositori.find();
    }
    GetApuestaLista():Promise<Apuesta[]>{
        return this.apuestaRepositori.find(
            {
                where:{Estado:1},
                //skip:3,// inicio
                //take:3// cantidad
            }
        );
    }

    Agregarapuestas(apuestas:Apuesta){
        let apuestasEntity = new ApuestasEntity();
        apuestasEntity.NombreApuestas = apuestas.NombreApuestas;
        apuestasEntity.Monto = apuestas.Monto;
        

        return this.apuestaRepositori.save(apuestasEntity);
    }

    async EditarApuestas(id:string, apuesta:Stadium){
        let apuestaEntity = await this. apuestaRepositori.findOneBy({Id:Number(id)})
        if(!apuestaEntity)
        return new Promise ((resolve,reject)=>{
            resolve(null);
        });
        apuestaEntity.Nombreapuesta = apuesta.Nombreapuesta;
        apuestaEntity.Lugar = apuesta.Lugar;
        return this.apuestaRepositori.save(apuestaEntity);
    }

    BorrarApuestas(id:string){
        return this.apuestaRepositori.delete({Id:Number(id)})
    }


    GetApuestasListaPaginar(skip:number,take:number):Promise<Apuesta[]>{
        return this.apuestaRepositori.find(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
    }
    async GetApuestasListaPaginarPorPagina(skip:number,take:number):Promise<any>{
        const [lista,count]= await this.apuestaRepositori.findAndCount(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
        //console.log(lista,count);
        return {lista,count,skip,take};
    }
    GetApuestas():Promise<any>{
        return this.apuestaRepositori.find(
            {where:{Estado:1}}
        );
    }
}
