import { Injectable } from '@nestjs/common';
import { UsuarioService } from '../usuario/usuario.service';
import { hash } from 'bcrypt';
@Injectable()
export class AuthService {
    constructor(
        private usuarioService:UsuarioService
    ){}
    async validateUser(login:string,password:string)
    :Promise<any>{
        console.log("aaaaaaa");
        const user=await this.usuarioService.findOne(login,password);
        if(user){
            const {Password,...resultado} = user;
            return resultado;
        }
        else
            return null;
    }
    register(user){

    }
}
