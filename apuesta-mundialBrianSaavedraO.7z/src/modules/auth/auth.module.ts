import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';

import { PassportModule } from '@nestjs/passport';

import { UsuarioModule } from '../usuario/usuario.module';
import { AuthController } from './auth.controller';
import { JwtModule } from '@nestjs/jwt';
import { jwtConstants } from 'src/constants/jwt.datos';
import { JwtStrategy } from './jwt.strategy';
@Module({
  imports:[
    UsuarioModule,
    JwtModule.register({
      secret:jwtConstants.secret,
      signOptions:{expiresIn:'60m'},
    })
   
],
  providers: [AuthService,JwtStrategy],
  controllers: [AuthController]
})
export class AuthModule {}
