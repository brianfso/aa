import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';


@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
    /*canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
        
    }*/
    handleRequest(err, user, info) {
        // You can throw an exception based on either "info" or "err" arguments
        console.log(err,user,info);
        if (err || !user) {
          throw err || new UnauthorizedException("no");
        }
        return user;
      }
}
