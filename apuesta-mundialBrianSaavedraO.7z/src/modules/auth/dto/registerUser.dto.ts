import { IsNotEmpty, IsString } from "class-validator";
import { UserDTO } from "./user.dto";
import { PartialType } from '@nestjs/swagger';

export class RegisterUserDto extends PartialType(UserDTO){
    @IsNotEmpty()
    Nombres:string;

    @IsNotEmpty()
    Apellidos:string;

    Estado:number;
}