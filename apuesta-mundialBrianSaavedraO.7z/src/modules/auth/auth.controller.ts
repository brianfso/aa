import { Body, Controller, Post } from '@nestjs/common';
import { UsuarioService } from '../usuario/usuario.service';
import { RegisterUserDto } from './dto/registerUser.dto';
import { UserDTO } from './dto/user.dto';

@Controller('auth')
export class AuthController {
    constructor(private usuarioService:UsuarioService){}
    @Post('register')
    register(@Body() user:RegisterUserDto){
        console.log("sii");
        return this.usuarioService.register(user);

    }

    @Post('login')
    login(@Body() userDto:UserDTO){
        return this.usuarioService.login(userDto);
    }
}
