import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { StadiumsEntity } from 'src/entities/stadiums.entity';
import { ConfigSistemaModule } from '../config-sistema/config-sistema.module';
import { StadiumsController } from './stadiums.controller';
import { StadiumsService } from './stadiums.service';

@Module({
  
    imports:[
      TypeOrmModule.forFeature([StadiumsEntity]),
      ConfigSistemaModule
    ],
    controllers: [StadiumsController],
    providers: [
    StadiumsService]
})
export class StadiumsModule {}
