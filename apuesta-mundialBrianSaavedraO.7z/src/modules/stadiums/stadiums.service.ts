import { Injectable } from '@nestjs/common';
import { StadiumsEntity } from 'src/entities/stadiums.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Stadium } from 'src/modelos/stadiums';


@Injectable()
export class StadiumsService {
    constructor(
        @InjectRepository(StadiumsEntity)
        private stadiumRepositori:Repository<StadiumsEntity>,
    ){}
    
    ListarCategoria(){
        return this.stadiumRepositori.find();
    }
    GetStadiumsLista():Promise<Stadium[]>{
        return this.stadiumRepositori.find(
            {
                where:{Estado:1},
                //skip:3,// inicio
                //take:3// cantidad
            }
        );
    }

    AgregarStadiums(stadiums:Stadium){
        let stadiumsEntity = new StadiumsEntity();
        stadiumsEntity.NombreStadiums = stadiums.NombreStadiums;
        stadiumsEntity.Lugar = stadiums.Lugar;
        

        return this.stadiumRepositori.save(stadiumsEntity);
    }

    async EditarStadiums(id:string, stadiums:Stadium){
        let stadiumsEntity = await this. stadiumRepositori.findOneBy({Id:Number(id)})
        if(!stadiumsEntity)
        return new Promise ((resolve,reject)=>{
            resolve(null);
        });
        stadiumsEntity.NombreStadiums = stadiums.NombreStadiums;
        stadiumsEntity.Lugar = stadiums.Lugar;
        return this.stadiumRepositori.save(stadiumsEntity);
    }

    BorrarStadiums(id:string){
        return this.stadiumRepositori.delete({Id:Number(id)})
    }


    GetStadiumsListaPaginar(skip:number,take:number):Promise<Stadium[]>{
        return this.stadiumRepositori.find(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
    }
    async GetStadiumsListaPaginarPorPagina(skip:number,take:number):Promise<any>{
        const [lista,count]= await this.stadiumRepositori.findAndCount(
            {
                where:{Estado:1},
                skip:skip,// inicio
                take:take// cantidad
            }
        );
        //console.log(lista,count);
        return {lista,count,skip,take};
    }
    GetStadiums():Promise<any>{
        return this.stadiumRepositori.find(
            {where:{Estado:1}}
        );
    }
}
