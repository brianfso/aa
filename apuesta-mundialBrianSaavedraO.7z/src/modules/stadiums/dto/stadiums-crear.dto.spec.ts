import { StadiumsCrearDto } from './stadiums-crear.dto';

describe('StadiumsCrearDto', () => {
  it('should be defined', () => {
    expect(new StadiumsCrearDto()).toBeDefined();
  });
});
