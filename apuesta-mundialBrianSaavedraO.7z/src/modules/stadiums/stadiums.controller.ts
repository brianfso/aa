import { Body, Controller, Delete, Get, HttpException, HttpStatus, Param, Post, Put, Query, UseGuards } from '@nestjs/common';
import { StadiumsEntity } from 'src/entities/stadiums.entity';
import { Stadium } from 'src/modelos/stadiums';
import { Repository } from 'typeorm';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { ConfigSistemaService } from '../config-sistema/config-sistema.service';
import { StadiumsService } from './stadiums.service';
import { InjectRepository } from '@nestjs/typeorm';
import { StadiumsCrearDto } from './dto/stadiums-crear.dto';


@Controller('stadiums')
export class StadiumsController {
    /**
 * lista-> get
 * insertr->post
 * editar->put
 * borrar->delete
 * 
 */
     constructor(
        private stadiumService:StadiumsService,
        private configService:ConfigSistemaService
       
        ){} 

        @UseGuards(JwtAuthGuard)
    @Get()
    ListaStadiums(){
        return this.stadiumService.GetStadiumsLista()
        .then(stadiumsServer=>{
            return stadiumsServer;
        })
    }
    
        @Post()
        AgregarStadiums(@Body() datosStadium:StadiumsCrearDto)
        {
            try{
                return this.stadiumService.AgregarStadiums(datosStadium)
                .then((equipoServer)=>{
                    return equipoServer;
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
        }
    
        @Get(":id")
        GetStadiums(@Param() parametros:{id})
        {
            try{
                return this.stadiumService.GetStadiums(parametros.id).then((stadiumsServer)=>{
                   return stadiumsServer; 
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
        }
    
        @Put("id")
        EditarStadiums(@Param()parametros:{id},@Body() stadiumsDto:StadiumsCrearDto){
            try{
                return this.stadiumService.EditarStadiums(parametros.id,stadiumsDto)
                .then((stadiumsServer)=>{
                    return stadiumsServer;
                });
            }
            catch(error){
                return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
            }
    
        }
    
        @Delete(":id")
        BorrarStadiums(@Param()parametros:{id:number})
        {
          try{
            return this.stadiumService.BorrarStadiums(parametros.id+'' )
            .then((equipoServer)=>{
                return(equipoServer)?
                equipoServer:{message:'No hay dato que borrar'};
            });
        }  
        catch(error){
            return new HttpException('Problems:'+error,HttpStatus.BAD_REQUEST)
        }
        }

    

    @UseGuards(JwtAuthGuard)
    @Get('listaPagina')
    ListaStadiumsPaginar(
        @Query() params:{skip:number,take:number})
    {
        
        const {skip, take}=params;
        return this.stadiumService.GetStadiumsListaPaginar(skip,take)
       
    }
    @Get('listaPaginaPorPagina')
    async ListaStadiumsPaginarPorPagina(
       
        @Query() params:{skip:number,take:number})
    {
        this.Inicializar();
        
        
        const cantidad= Number(await this.configService.GetConfig('cantidadPagina'));

        let {skip, take}=params;
        skip=skip?skip:0;
        take=take?take:cantidad;
        //console.log("parametros url5",skip,take)
        return  this.stadiumService.GetStadiumsListaPaginarPorPagina(skip,take)
        .then(stadiumsServer=>{
            return stadiumsServer;
        })
    }

    private async  Inicializar(){
        const cantidad= await this.configService.GetConfig("cantidadPagina");
        if(cantidad==='')
            this.configService.SetConfig("cantidadPagina",'5');
    }
}
