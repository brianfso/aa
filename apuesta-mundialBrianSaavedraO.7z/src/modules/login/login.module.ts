import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsuarioEntity } from 'src/entities/usuario.entity';
import { LoginController } from './login.controller';
import { LoginService } from './login.service';
import { JwtModule } from '@nestjs/jwt';
import { jwtConstants } from  '../../constants/jwt.datos';
//import { PassportModule } from '@nestjs/'

@Module({
  imports:[
    /*JwtModule.register({
      secret:jwtConstants.secret,
      signOptions:{expiresIn:'60s'}
    }),*/
    //PassportModule,
    TypeOrmModule.forFeature([UsuarioEntity])
  ],
  controllers: [LoginController],
  providers: [LoginService],
  //exports:[LoginService]
})
export class LoginModule {}
