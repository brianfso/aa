import { Body, Controller, Request, Post, UseGuards } from '@nestjs/common';
import { LoginService } from './login.service';
import { AuthGuard } from '@nestjs/passport';

@Controller('login')
export class LoginController {
    constructor(
        private loginService:LoginService
    ){}

    @UseGuards(AuthGuard('local'))
    @Post('login')
    Login(@Request() req)
    {
        console.log(req);
        return req.user;
       
    }
}
