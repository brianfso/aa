import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";


@Entity("tb_apuestas")
export class ApuestasEntity{
    @PrimaryGeneratedColumn()
    Id:number;

    @Column()
    Precio:number;
}