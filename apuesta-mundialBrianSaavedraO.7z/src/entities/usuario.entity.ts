import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";


@Entity("tb_usuario")
export class UsuarioEntity{
    @PrimaryGeneratedColumn()
    Id:number;

    @Column()
    Nombres:string;

    @Column()
    Apellidos:string;

    @Column()
    Login:string;

    @Column()
    Password:string;

    @Column({default:1})
    Estado:number;
}