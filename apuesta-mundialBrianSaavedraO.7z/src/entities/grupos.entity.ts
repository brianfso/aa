import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity("tb_grupos")
export class GruposEntity{
    @PrimaryGeneratedColumn()
    Id:number;

    @Column()
    NombreGrupos:string;

}