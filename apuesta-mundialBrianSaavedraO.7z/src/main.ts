import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import * as cookieParser from 'cookie-parser';
import * as session from 'express-session';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.useGlobalPipes(new ValidationPipe({
    whitelist:true,
    transform:true
  }));

  const config = new DocumentBuilder()
    .addBearerAuth()
    .setTitle('Apuestas para el mundial')
    .setDescription('La API de apuestas del mundial...')
    .setVersion('0.0.0.1')
    .addTag('Api modulos apuestas')
    .build();
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('api', app, document);

    app.use(cookieParser());
  app.use(
    session({
      secret: 'my-secret',
      resave: false,
      saveUninitialized: true,
    }),
  );

  app.enableCors();
  console.log(__dirname);

  await app.listen(3000);
}
bootstrap();
