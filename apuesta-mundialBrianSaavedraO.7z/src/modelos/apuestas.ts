export class Apuestas{

    Id:number=0;
    Precio:number=0;


}