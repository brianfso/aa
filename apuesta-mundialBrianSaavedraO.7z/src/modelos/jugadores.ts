export class Jugadores{

    Id:number=0;
    NombreJugador:string='';
    NumeroJugador:number=0;
   
    

}