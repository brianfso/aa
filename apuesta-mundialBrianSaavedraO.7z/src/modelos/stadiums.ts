export class Stadium{

    Id:number=0;
    NombreStadiums:string='';
    Lugar:string='';
    

}