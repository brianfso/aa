export class Grupos{

    Id:number=0;
    NombreGrupos:string='';
   
    

}